sudo add-apt-repository -y ppa:ethereum/ethereum
sudo apt-get update
sudo apt-get install -y ethereum
nohup geth --goerli --syncmode "light" --ws &
